using UnityEngine;

public class TouchController : MonoBehaviour
{
    public float walkSpeed = 3.0f;
    private Rigidbody2D rb;
    public float movX = 0f;
    public float movY = 0f;
    private bool reverse = false;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }
    void FixedUpdate()
    {
        rb.linearVelocity = new Vector2(movX * walkSpeed, movY * walkSpeed);
    }

    // Update is called once per frame
    void Update()
    {
        movX = 0f;
        movY = 0f;

        if (Input.GetMouseButton(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                GameObject touchedObject = hit.collider.gameObject;
                if (touchedObject.CompareTag("Reverse"))
                {
                    reverse = !reverse;
                }
                if (!reverse)
                {
                    if (touchedObject.CompareTag("Up"))
                    {
                        movY = 1;
                    }
                    else if (touchedObject.CompareTag("Left"))
                    {
                        movX = -1;
                    }
                    else if (touchedObject.CompareTag("Right"))
                    {
                        movX = 1;
                    }
                    else if (touchedObject.CompareTag("Down"))
                    {
                        movY = -1;
                    }
                }

                else
                {
                    if (touchedObject.CompareTag("Up"))
                    {
                        movY = -1;
                    }
                    else if (touchedObject.CompareTag("Left"))
                    {
                        movX = 1;
                    }
                    else if (touchedObject.CompareTag("Right"))
                    {
                        movX = -1;
                    }
                    else if (touchedObject.CompareTag("Down"))
                    {
                        movY = 1;
                    }
                }
            }
        }
    }
}