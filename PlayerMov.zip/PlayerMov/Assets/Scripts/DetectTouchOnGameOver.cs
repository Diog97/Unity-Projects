using UnityEngine;

public class DetectTouchOnGameOver : MonoBehaviour
{
    public Transform configPosition;
    public Transform homePosition;
    public Transform phasesPosition;
    public float velocity = 2.0f;
    private Transform target;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        target = homePosition;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                GameObject touchedObject = hit.collider.gameObject;

                if (touchedObject.CompareTag("Play"))
                {
                    target = phasesPosition;
                }
                else if (touchedObject.CompareTag("Config"))
                {
                    target = configPosition;
                }
                else if (touchedObject.CompareTag("Home"))
                {
                    target = homePosition;
                }
            }
        }


        if (target != null)
        {
            transform.position = Vector3.Lerp(transform.position, target.position, velocity * Time.deltaTime);
        }
    }
}
