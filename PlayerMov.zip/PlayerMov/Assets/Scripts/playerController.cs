using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [Header("Player Animation")]
    public Animator animatorPlayer;
    public TouchController movementScript;

    // Start is called once before the first execution of Update after the MonoBehaviour is created

    void FixedUpdate()
    {
        float movX = movementScript.movX;
        float movY = movementScript.movY;

        UpdateAnimation(movX, movY);
    }

    void UpdateAnimation(float movX, float movY)
    {
        bool walkRight = movX > 0;
        bool walkLeft = movX < 0;
        bool walkUp = movY > 0;
        bool walkDown = movY < 0;

        animatorPlayer.SetBool("WalkRight", walkRight);
        animatorPlayer.SetBool("WalkLeft", walkLeft);
        animatorPlayer.SetBool("WalkUp", walkUp);
        animatorPlayer.SetBool("WalkDown", walkDown);
    }
}
